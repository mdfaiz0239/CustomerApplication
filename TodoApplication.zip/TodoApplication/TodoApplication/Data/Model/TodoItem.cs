﻿using System.ComponentModel.DataAnnotations;

namespace TodoApplication.Data.Model
{
    public class TodoItem
    {
        [Key]
        public Guid Id { get; set; }

        
        public string Name { get; set; }=string.Empty;


        public string CollegeId { get; set; } = string.Empty;

        
        public string EducationId { get; set; } = string.Empty;

        
        public string TechnologyId { get; set; } = string.Empty;

        public string Status { get; set; } = string.Empty;
    }
}
