using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using TodoApplication.Data.Context;
using TodoApplication.Data.Model;
using TodoApplication.Models;

namespace TodoApplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly TodoContext _context;

        public HomeController(TodoContext context, ILogger<HomeController> logger)
        {
            _logger = logger;
            _context = context;
        }

        List<SelectListItem> Colleges = new List<SelectListItem>
        {
            new SelectListItem { Text = "-- Select College --", Value = "0" },
         new SelectListItem { Text = "IIT Delhi", Value = "1" },
         new SelectListItem { Text = "IIT Bombay", Value = "2" },
         new SelectListItem { Text = "NIT Trichy", Value = "3" },
         new SelectListItem { Text = "Delhi University", Value = "4" },
         new SelectListItem { Text = "Amity University", Value = "5" }
        };

        List<SelectListItem> Educations = new List<SelectListItem>
        {
            new SelectListItem { Text = "-- Select Education --", Value = "0" },
            new SelectListItem { Text = "B.Tech", Value = "1" },
            new SelectListItem { Text = "M.Tech", Value = "2" },
            new SelectListItem { Text = "B.Sc", Value = "3" },
            new SelectListItem { Text = "M.Sc", Value = "4" },
            new SelectListItem { Text = "MBA", Value = "5" }
        };

        List<SelectListItem> Techologies = new List<SelectListItem>
        {
            new SelectListItem { Text = "-- Select Technology --", Value = "0" },
            new SelectListItem { Text = "C#", Value = "1" },
            new SelectListItem { Text = ".NET Core", Value = "2" },
            new SelectListItem { Text = "Angular", Value = "3" },
            new SelectListItem { Text = "React", Value = "4" },
            new SelectListItem { Text = "SQL Server", Value = "5" },
            new SelectListItem { Text = "Azure", Value = "6" }
        };

        List<SelectListItem> StatusList = new List<SelectListItem>
        {
            new SelectListItem { Value = "Pending", Text = "Pending" },
            new SelectListItem { Value = "Complete", Text = "Complete" },
            new SelectListItem { Value = "Screened", Text = "Screened" }
        };


        [HttpGet]
        public IActionResult Index(Guid? Id)
        {
            TodoItem objEdit = null; // for edit case
            var todoitems = _context.TodoItems.ToList();
            var TodoList = (from t in todoitems
                            join c in Colleges on t.CollegeId.ToString() equals c.Value
                            join e in Educations on t.EducationId.ToString() equals e.Value
                            join tech in Techologies on t.TechnologyId.ToString() equals tech.Value
                            select new TodoDataList
                            {
                                Id = t.Id,
                                Name = t.Name,
                                CollegeName = c.Text,
                                EducationName = e.Text,
                                TechnologyName = tech.Text,
                                Status = t.Status,
                            }).ToList();
            TodoResponseModel obj = new TodoResponseModel();
            if (Id.HasValue)
            {
                objEdit = todoitems.FirstOrDefault(x => x.Id == Id);
                if (objEdit != null)
                {
                    obj.Id = objEdit.Id;
                    obj.Name = objEdit.Name;
                    obj.CollegeId = Convert.ToInt32(objEdit.CollegeId);
                    obj.EducationId = Convert.ToInt32(objEdit.EducationId);
                    obj.TechnologyId = Convert.ToInt32(objEdit.TechnologyId);
                }


            }

            obj.todoDataLists = TodoList;
            obj.Educations = Educations;
            obj.Techologies = Techologies;
            obj.Colleges = Colleges;
            obj.StatusList = StatusList;
            return View(obj);
        }

        [HttpPost]
        public IActionResult Index(TodoResponseModel model)
        {
            //// Always re-bind dropdowns first in case model is invalid or exception occurs
            model.Colleges = Colleges;
            model.Techologies = Techologies;
            model.Educations = Educations;
            model.StatusList = StatusList;
            var todoitems = _context.TodoItems.ToList();
            var TodoList = (from t in todoitems
                            join c in Colleges on t.CollegeId.ToString() equals c.Value
                            join e in Educations on t.EducationId.ToString() equals e.Value
                            join tech in Techologies on t.TechnologyId.ToString() equals tech.Value
                            select new TodoDataList
                            {
                                Id = t.Id,
                                Name = t.Name,
                                CollegeName = c.Text,
                                EducationName = e.Text,
                                TechnologyName = tech.Text,
                                Status = t.Status,
                            }).ToList();
            model.todoDataLists = TodoList;
            if (!ModelState.IsValid)
                return View(model); // Model validation failed

            try
            {
                string Message = "Todo Updated successfully!";
                TodoItem? todoItem = null;
                todoItem = model.Id.HasValue ? _context.TodoItems.FirstOrDefault(x => x.Id == model.Id) : new TodoItem();
                todoItem.Name = model.Name;
                todoItem.EducationId = model.EducationId.ToString();
                todoItem.CollegeId = model.CollegeId.ToString();
                todoItem.TechnologyId = model.TechnologyId.ToString();
                todoItem.Status = "Pending";
                if (!model.Id.HasValue)
                {
                    todoItem.Id = Guid.NewGuid();
                    _context.Add(todoItem);
                    Message = "Todo Added successfully!";
                }
                else
                    model.Id = null;
                _context.SaveChanges();
                TempData["Success"] = Message;
                ModelState.Clear();
                return RedirectToAction("Index", new { id = model.Id });
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Something went wrong while saving the data. Please try again.");
                return View(model);

            }

        }

        [HttpGet]
        public IActionResult Delete(Guid id)
        {
            try
            {
                var item = _context.TodoItems.FirstOrDefault(x => x.Id == id);
                if (item == null)
                {
                    return NotFound();
                }

                _context.TodoItems.Remove(item);
                _context.SaveChanges();
                TempData["Success"] = "Item deleted successfully!";
            }
            catch (Exception ex)
            {
                // Log error and show message
                Console.WriteLine(ex.Message);
                TempData["Error"] = "Error while deleting item.";
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult UpdateStatus(Guid id, string newStatus)
        {
            var todoItem = _context.TodoItems.FirstOrDefault(x => x.Id == id);
            if (todoItem != null)
            {
                todoItem.Status = newStatus;
                _context.SaveChanges();
            }

            return RedirectToAction("Index");
        }

        public IActionResult GetTodoItemDetails(Guid id)
        {
            // fetch the data
            var item = _context.TodoItems
                .FirstOrDefault(x => x.Id == id);

            if (item == null) return NotFound();

            // Ab College, Education, Technology ke names local lists se maping
            var collegeName = Colleges.FirstOrDefault(e => e.Value == item.CollegeId.ToString())?.Text;
            var educationName = Educations.FirstOrDefault(e => e.Value == item.EducationId.ToString())?.Text;
            var technologyName = Techologies.FirstOrDefault(t => t.Value == item.TechnologyId.ToString())?.Text;

            var todoItem = new
            {
                item.Name,
                CollegeName = collegeName,
                EducationName = educationName,
                TechnologyName = technologyName,
                item.Status
            };

            return Json(todoItem);
        }



        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
