﻿namespace CustomerApplication.Data.Models
{
    public class Gender
    {
        public byte Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public ICollection<CustomerInfo> Customers { get; set; }
    }
}
