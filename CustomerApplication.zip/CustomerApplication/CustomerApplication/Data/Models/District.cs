﻿namespace CustomerApplication.Data.Models
{
    public class District
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int StateId { get; set; }

        public State State { get; set; }
        public ICollection<CustomerInfo> Customers { get; set; }
    }
}
