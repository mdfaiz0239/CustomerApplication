﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace CustomerApplication.Data.Models
{
    public class ApplicationUser :IdentityUser
    {
        [Required]
        [StringLength(10, ErrorMessage = "Max 10 characters")]
        [RegularExpression(@"^[a-zA-Z0-9_]+$", ErrorMessage = "Only letters, numbers and underscore (_) allowed.")]
        public string DomainName { get; set; } = string.Empty;
        
    }
}
