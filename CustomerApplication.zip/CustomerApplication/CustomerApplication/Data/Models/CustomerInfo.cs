﻿using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace CustomerApplication.Data.Models
{
    public class CustomerInfo
    {
        public int Id { get; set; }

       
        public string Name { get; set; } = string.Empty;

      
        public byte GenderId { get; set; }

       
        public int DistrictId { get; set; }

        //Navigation Properties
        public Gender Gender { get; set; }
        public District District { get; set; }
    }
}
