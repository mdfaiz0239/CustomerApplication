using System.Diagnostics;
using CustomerApplication.Data.Context;
using CustomerApplication.Data.Models;
using CustomerApplication.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CustomerApplication.Controllers
{
    [Authorize]
    public class CustomerController : Controller
    {
        private readonly ILogger<CustomerController> _logger;
        private readonly ApplicationContext _context;

        public CustomerController(ILogger<CustomerController> logger, ApplicationContext context)
        {
            _logger = logger;
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            //var customers = await _context.CustomerInfos
            //.Include(c => c.Gender)
            //.Include(c => c.District)
            //.ThenInclude(d => d.State)
            //.ToListAsync();
            var customers = await (
                            from customer in _context.CustomerInfos
                            join gender in _context.Genders on customer.GenderId equals gender.Id
                            join district in _context.Districts on customer.DistrictId equals district.Id
                            join state in _context.States on district.StateId equals state.Id
                            select new CustomerList
                            {
                                Id = customer.Id,
                                Name = customer.Name,
                                GenderName = gender.Name,
                                DistricName = district.Name,
                                StateName = state.Name,
                                GenderId = gender.Id,
                                StateId = state.Id,
                                DistrictId = district.Id
                            }).ToListAsync();
            AddCustomers customersDetails = new AddCustomers()
            {
                customerDetails = customers
            };
           
            ViewBag.Genders = await _context.Genders.ToListAsync();
            ViewBag.States = await _context.States.ToListAsync();

            return View(customersDetails);
        }

        [HttpPost]
        public async Task<IActionResult> AddUpdate(AddCustomers customer)
        {
            
            if (ModelState.IsValid)
            {
                
                try
                {

                    var message = "Customer Updated"; 
                    if (customer != null)
                    {
                        CustomerInfo? cust = customer.Id.HasValue ? await _context.CustomerInfos.FindAsync(customer.Id) : new CustomerInfo();

                        cust.Name = customer.Name;
                        cust.GenderId = customer.GenderId;
                        cust.DistrictId = customer.DistrictId;
                        

                        if (!customer.Id.HasValue)
                        {
                            _context.CustomerInfos.Add(cust);
                            message = "Customer Added";
                        }
                        await _context.SaveChangesAsync();
                        return Json(new { success = true,message=message });
                    }
                    else
                        return Json(new { success = false, message = "model can not be null" });
                }
                catch (Exception ex)
                {
                    return Json(new { success = false, message = ex.Message });
                }
            }

            return Json(new { success = false, message = "Validation failed." });
        }

        [HttpGet]
        public async Task<IActionResult> GetDistricts(int stateId)
        {
            var districts = await _context.Districts
                .Where(d => d.StateId == stateId)
                .Select(d => new { d.Id, d.Name })
                .ToListAsync();

            return Json(districts);
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var customer = await _context.CustomerInfos.FindAsync(id);
            if (customer == null)
                return Json(new { success = false, message = "Customer not found." });

            try
            {
                _context.CustomerInfos.Remove(customer);
                await _context.SaveChangesAsync();
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        
    }
}
