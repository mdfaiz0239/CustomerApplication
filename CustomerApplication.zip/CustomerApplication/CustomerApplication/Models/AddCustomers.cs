﻿using CustomerApplication.Data.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.ComponentModel.DataAnnotations;

namespace CustomerApplication.Models
{
    public class AddCustomers
    {
        public int? Id { get; set; }
        [Required]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Only alphabets are allowed.")]
        public string Name { get; set; } = string.Empty;

        [Required]
        [Range(1, 255)]
        public byte GenderId { get; set; }

        [Required]
        public int DistrictId { get; set; }

        public List<CustomerList> customerDetails { get; set; } = new List<CustomerList>();
        


    }

    public class CustomerList
    {
        public int? Id { get; set; }
        
        public string Name { get; set; } = string.Empty;

        public byte GenderId { get; set; }

        public int DistrictId { get; set; }
        public int StateId { get; set; }

        public string GenderName { get; set; } = string.Empty;
        public string DistricName { get; set; } = string.Empty;

        public string StateName { get; set; } = string.Empty;
    }

    
}
