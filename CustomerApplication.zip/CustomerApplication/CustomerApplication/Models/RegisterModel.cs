﻿using System.ComponentModel.DataAnnotations;

namespace CustomerApplication.Models
{
    public class RegisterModel
    {
        [Required, EmailAddress]
        public string Email { get; set; }=string.Empty;

        [Required, DataType(DataType.Password)]
        public string Password { get; set; }=string.Empty;

        [Required]
        [StringLength(10)]
        [RegularExpression(@"^[a-zA-Z0-9_]+$", ErrorMessage = "Only letters, numbers and underscore (_) allowed.")]
        public string DomainName { get; set; }=string.Empty;
    }
}
