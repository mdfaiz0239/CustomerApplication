﻿using Microsoft.EntityFrameworkCore;
using TodoApplication.Data.Model;

namespace TodoApplication.Data.Context
{
    public class TodoContext: DbContext
    {
        public TodoContext(DbContextOptions<TodoContext> options) :base(options) { }

        public DbSet<TodoItem> TodoItems { get; set; }
        public DbSet<College> College { get; set; }
        public DbSet<Education> Education { get; set; }
        public DbSet<Technology> Technology { get; set; }
        public DbSet<StatusType> StatusTypes { get; set; }
        public DbSet<User> User { get; set; }
    }
}
