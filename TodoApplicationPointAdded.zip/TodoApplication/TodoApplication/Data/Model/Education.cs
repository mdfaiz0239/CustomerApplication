﻿using System.ComponentModel.DataAnnotations;

namespace TodoApplication.Data.Model
{
    public class Education
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;

        public int CollegeId { get; set; }
        public College College { get; set; }

        public ICollection<Technology> Technologies { get; set; }
        public ICollection<TodoItem> TodoItems { get; set; }
    }
}
