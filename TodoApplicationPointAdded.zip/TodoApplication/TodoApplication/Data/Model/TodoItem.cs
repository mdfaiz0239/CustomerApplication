﻿using System.ComponentModel.DataAnnotations;

namespace TodoApplication.Data.Model
{
    public class TodoItem
    {
        [Key]
        public Guid Id { get; set; }
        
        public string Name { get; set; }=string.Empty;

        public int CollegeId { get; set; }
        public College College { get; set; }

        public int EducationId { get; set; }
        public Education Education { get; set; }

        public int TechnologyId { get; set; }
        public Technology Technology { get; set; }

        public int? AssignedUserId { get; set; } // Nullable FK
        public User AssignedUser { get; set; }   // Navigation property
        public string Status { get; set; } = string.Empty;
    }
}
