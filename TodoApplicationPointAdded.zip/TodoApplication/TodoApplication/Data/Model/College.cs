﻿using System.ComponentModel.DataAnnotations;

namespace TodoApplication.Data.Model
{
    public class College
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;

        public ICollection<Education> Educations { get; set; }
        public ICollection<TodoItem> TodoItems { get; set; }


    }
}
