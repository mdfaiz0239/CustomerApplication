﻿namespace TodoApplication.Data.Model
{
    public class StatusType
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;
    }
}
