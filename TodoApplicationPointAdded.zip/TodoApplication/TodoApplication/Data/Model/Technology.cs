﻿using System.ComponentModel.DataAnnotations;

namespace TodoApplication.Data.Model
{
    public class Technology
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }=string.Empty;

        public int EducationId { get; set; }
        public Education Education { get; set; }
        public ICollection<TodoItem> TodoItems { get; set; }
    }
}
