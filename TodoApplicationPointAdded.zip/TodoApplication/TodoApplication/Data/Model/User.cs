﻿namespace TodoApplication.Data.Model
{
    public class User
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public ICollection<TodoItem> AssignedTodos { get; set; }  // Navigation property
    }
}
