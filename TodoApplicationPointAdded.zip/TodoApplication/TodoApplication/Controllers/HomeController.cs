using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using TodoApplication.Data.Context;
using TodoApplication.Data.Model;
using TodoApplication.Models;

namespace TodoApplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly TodoContext _context;

        public HomeController(TodoContext context, ILogger<HomeController> logger)
        {
            _logger = logger;
            _context = context;
        }



        [HttpGet]
        public IActionResult Index(Guid? Id)
        {
            TodoItem objEdit = null; // for edit case
            TodoResponseModel obj = new TodoResponseModel();
            var todoitems = _context.TodoItems.ToList();
            obj.Colleges = _context.College
                       .Select(x => new SelectListItem
                       {
                           Value = x.Id.ToString(),
                           Text = x.Name
                       }).ToList();
            var TodoList = (from t in todoitems
                            join c in _context.College on t.CollegeId equals c.Id
                            join e in _context.Education on t.EducationId equals e.Id
                            join tech in _context.Technology on t.TechnologyId equals tech.Id
                            join u in _context.User on t.AssignedUserId equals u.Id into userJoin
                            from u in userJoin.DefaultIfEmpty() // Left Join on User
                            select new TodoDataList
                            {
                                Id = t.Id,
                                Name = t.Name,
                                CollegeName = c.Name,
                                EducationName = e.Name,
                                TechnologyName = tech.Name,
                                Status = t.Status,
                                UserId = t.AssignedUserId,
                                //AssignedUserName = u != null ? u.FullName : "Not Assigned"
                            }).ToList();

            if (Id.HasValue)
            {
                objEdit = todoitems.FirstOrDefault(x => x.Id == Id);
                if (objEdit != null)
                {
                    obj.Id = objEdit.Id;
                    obj.Name = objEdit.Name;
                    obj.CollegeId = objEdit.CollegeId;
                    obj.EducationId = objEdit.EducationId;
                    obj.TechnologyId = objEdit.TechnologyId;
                    obj.Educations = _context.Education
                   .Where(x => x.CollegeId == objEdit.CollegeId)
                   .Select(x => new SelectListItem
                   {
                       Value = x.Id.ToString(),
                       Text = x.Name
                   }).ToList();

                    // Load Technology list based on selected EducationId
                    obj.Techologies = _context.Technology
                        .Where(x => x.EducationId == objEdit.EducationId)
                        .Select(x => new SelectListItem
                        {
                            Value = x.Id.ToString(),
                            Text = x.Name
                        }).ToList();
                }


            }
            else
            {
                obj.Educations = new List<SelectListItem>();
                obj.Techologies = new List<SelectListItem>();
            }

            obj.todoDataLists = TodoList;

            obj.StatusList = _context.StatusTypes
                      .Select(x => new SelectListItem
                      {
                          Value = x.Id.ToString(),
                          Text = x.Name
                      }).ToList();
            obj.UserList = _context.User
                         .Select(u => new SelectListItem
                         {
                             Value = u.Id.ToString(),
                             Text = u.Name
                         }).ToList();
            return View(obj);
        }

        [HttpPost]
        public IActionResult Index(TodoResponseModel model)
        {
            //// Always re-bind dropdowns first in case model is invalid or exception occurs
            model.Colleges = _context.College
                      .Select(x => new SelectListItem
                      {
                          Value = x.Id.ToString(),
                          Text = x.Name
                      }).ToList();
            model.StatusList = _context.StatusTypes
                      .Select(x => new SelectListItem
                      {
                          Value = x.Id.ToString(),
                          Text = x.Name
                      }).ToList();
            var todoitems = _context.TodoItems.ToList();
            var TodoList = (from t in todoitems
                            join c in _context.College on t.CollegeId equals c.Id
                            join e in _context.Education on t.EducationId equals e.Id
                            join tech in _context.Technology on t.TechnologyId equals tech.Id
                            select new TodoDataList
                            {
                                Id = t.Id,
                                Name = t.Name,
                                CollegeName = c.Name,
                                EducationName = e.Name,
                                TechnologyName = tech.Name,
                                Status = t.Status,
                            }).ToList();
            model.todoDataLists = TodoList;
            if (!ModelState.IsValid)
                return View(model); // Model validation failed

            try
            {
                string Message = "Todo Updated successfully!";
                TodoItem? todoItem = null;
                todoItem = model.Id.HasValue ? _context.TodoItems.FirstOrDefault(x => x.Id == model.Id) : new TodoItem();
                todoItem.Name = model.Name;
                todoItem.EducationId = model.EducationId;
                todoItem.CollegeId = model.CollegeId;
                todoItem.TechnologyId = model.TechnologyId;

                if (!model.Id.HasValue)
                {
                    todoItem.Id = Guid.NewGuid();
                    todoItem.Status = "2"; // for pending
                    _context.Add(todoItem);
                    Message = "Todo Added successfully!";
                }
                else
                    model.Id = null;
                _context.SaveChanges();
                TempData["Success"] = Message;
                ModelState.Clear();
                return RedirectToAction("Index", new { id = model.Id });
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Something went wrong while saving the data. Please try again.");
                return View(model);

            }

        }

        [HttpGet]
        public IActionResult Delete(Guid id)
        {
            try
            {
                var item = _context.TodoItems.FirstOrDefault(x => x.Id == id);
                if (item == null)
                {
                    return NotFound();
                }

                _context.TodoItems.Remove(item);
                _context.SaveChanges();
                TempData["Success"] = "Item deleted successfully!";
            }
            catch (Exception ex)
            {
                // Log error and show message
                Console.WriteLine(ex.Message);
                TempData["Error"] = "Error while deleting item.";
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult UpdateStatus(Guid id, string newStatus)
        {
            var todoItem = _context.TodoItems.FirstOrDefault(x => x.Id == id);
            if (todoItem != null)
            {
                todoItem.Status = newStatus;
                _context.SaveChanges();
                return Ok();
            }

            return BadRequest();
        }

        public IActionResult GetTodoItemDetails(Guid id)
        {
            // fetch the data
            var item = _context.TodoItems
                .FirstOrDefault(x => x.Id == id);

            if (item == null) return NotFound();

            // Ab College, Education, Technology ke names local lists se maping
            var collegeName = _context.College.FirstOrDefault(e => e.Id == item.CollegeId)?.Name;
            var educationName = _context.Education.FirstOrDefault(e => e.Id == item.EducationId)?.Name;
            var technologyName = _context.Technology.FirstOrDefault(t => t.Id == item.TechnologyId)?.Name;

            var todoItem = new
            {
                item.Name,
                CollegeName = collegeName,
                EducationName = educationName,
                TechnologyName = technologyName,
                status = _context.StatusTypes.FirstOrDefault(x => x.Id.ToString() == item.Status)?.Name,
                user = _context.User.FirstOrDefault(x => x.Id == item.AssignedUserId)?.Name
            };

            return Json(todoItem);
        }

        [HttpGet]
        public JsonResult GetEducationListByCollegeId(int collegeId)
        {
            var educationList = _context.Education
                .Where(e => e.CollegeId == collegeId)
                .Select(e => new SelectListItem
                {
                    Value = e.Id.ToString(),
                    Text = e.Name
                }).ToList();

            return Json(educationList);
        }


        [HttpGet]
        public JsonResult GetTechnologyListByEducationId(int educationId)
        {
            var techList = _context.Technology
                .Where(t => t.EducationId == educationId)
                .Select(t => new SelectListItem
                {
                    Value = t.Id.ToString(),
                    Text = t.Name
                }).ToList();

            return Json(techList);
        }


        [HttpPost]
        public IActionResult AssignUser(Guid todoId, int? userId)
        {
            var todo = _context.TodoItems.FirstOrDefault(t => t.Id == todoId);
            if (todo != null)
            {
                todo.AssignedUserId = userId;
                _context.SaveChanges();
                return Ok();
            }
            return BadRequest();
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
