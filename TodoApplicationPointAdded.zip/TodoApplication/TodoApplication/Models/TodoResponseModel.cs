﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace TodoApplication.Models
{
    public class TodoResponseModel
    {

        public Guid? Id { get; set; }
        [Required(ErrorMessage = "Todo Name Required")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select a college")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select a college")]
        public int CollegeId { get; set; } = 0;

        //[Required(ErrorMessage = "Please select a Education")]
        [Range(1, int.MaxValue, ErrorMessage = "First select a valid college")]
        public int EducationId { get; set; } = 0;

        //[Required(ErrorMessage = "Please select a Technolgy")]
        [Range(1, int.MaxValue, ErrorMessage = "First select a valid Education")]
        public int TechnologyId { get; set; } = 0;

        public string Status { get; set; } = string.Empty;

        // For dropdown binding
        public List<SelectListItem> Colleges { get; set; } = new List<SelectListItem>();
        public List<SelectListItem> Educations { get; set; } = new List<SelectListItem>();
        public List<SelectListItem> Techologies { get; set; } = new List<SelectListItem>();
        public List<SelectListItem> StatusList { get; set; } = new List<SelectListItem>();

        public List<TodoDataList>? todoDataLists { get; set; } = null;
        public List<SelectListItem> UserList { get; set; }=new List<SelectListItem>();



    }

    public class TodoDataList
    {
        public Guid? Id { get; set; }
        public string Name { get; set; } = string.Empty;

        public string CollegeName { get; set; } = string.Empty;
        public string EducationName { get; set; } = string.Empty;
        public string TechnologyName { get; set; } = string.Empty;
        public string Status { get; set; } = "Pending";
        public int? UserId { get; set; }
    }
}
